use default;
drop table aztest;
create table aztest(phonenbr int ,flow int)
row format delimited fields terminated by ',';